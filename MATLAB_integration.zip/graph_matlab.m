% Your MATLAB script code to create a figure
x = linspace(0, 2*pi, 100);
y = sin(x);
figure;
plot(x, y);
xlabel('x-axis')
ylabel('y-axis')

% Save the figure
saveas(gcf, 'sine_wave_plot.png');  % You can specify the file format (e.g., 'sine_wave_plot.pdf', 'sine_wave_plot.fig', etc.)

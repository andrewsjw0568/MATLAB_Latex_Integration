% Test m - file
for i =1:10
fprintf ( ' Print % d \ n ' , i )
end